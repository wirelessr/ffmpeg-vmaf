/*
 * cpu_info.c
 *
 *  Created on: 14.02.2018
 *      Author: thomas
 */

int getNumCores();
